﻿using BusinessRuleEngine.ProductRule;
using BusinessRuleEngine.Resolver;
using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessRuleEngine
{
    public class BusinesssRuleManager : IBusinesssRuleManager
    {
        private readonly IEnumerable<IEventServiceOperation> _operators;

        public BusinesssRuleManager(IEnumerable<IEventServiceOperation> operators)
        {
            _operators = operators;
        }

        public void ApplyStrategy(string type, string eventModel)
        {
            if (_operators.FirstOrDefault(x => x.operation.ToString().Equals(type, StringComparison.OrdinalIgnoreCase)) == null)
            {
                Console.WriteLine("Operation Not Exist");
            }
            else
            {
                _operators.FirstOrDefault(x => x.operation.ToString().Equals(type, StringComparison.OrdinalIgnoreCase)).DoThing(eventModel);
            }
        }
    }

}
