﻿using BusinessRuleEngine.Resolver;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine
{
    public class ConsoleApplication
    {
        private readonly IBusinesssRuleManager _customer;
        public ConsoleApplication(IBusinesssRuleManager customer)
        {
            _customer = customer;
        }

        public void Run(string type,string eventModel)
        {
            _customer.ApplyStrategy(type, eventModel);
        }
    }
}
