﻿using BusinessRuleEngine.Resolver;
using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.ProductRule
{
    public class BookRule : IEventServiceOperation
    {
        private readonly IReciptService reciptService;
        private readonly IPaymentService paymentService;
        public BookRule(IReciptService reciptService, IPaymentService paymentService)
        {
            this.reciptService = reciptService;
            this.paymentService = paymentService;
        }
        public Operation operation => Operation.OrderBook;
        public void DoThing(string eventDefined)
        {
            Console.WriteLine("Book Service");
            this.reciptService.DuplicateRecipt(eventDefined);
            this.paymentService.GenerateCommissionPayment(eventDefined);
        }
    }
}
