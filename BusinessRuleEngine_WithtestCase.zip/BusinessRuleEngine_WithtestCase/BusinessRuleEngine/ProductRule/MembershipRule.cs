﻿using BusinessRuleEngine.Resolver;
using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.ProductRule
{
    public class MembershipRule : IEventServiceOperation
    {
        private readonly IMembership membership;
        private readonly IEmailService emailService;
        public MembershipRule(IMembership membership, IEmailService emailService)
        {
            this.membership = membership;
            this.emailService = emailService;
        }
        public Operation operation => Operation.Membership;

        public void DoThing(string eventDefined)
        {
            Console.WriteLine("I am membership Service");
            this.membership.GenerateMembership(eventDefined);
            this.emailService.SendMail(eventDefined);
        }
    }
}
