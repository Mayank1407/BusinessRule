﻿using BusinessRuleEngine.Resolver;
using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.ProductRule
{
    public class PhysicalProduct : IEventServiceOperation
    {
        private readonly IReciptService reciptService;
        private readonly IPaymentService paymentService;
        public PhysicalProduct(IReciptService reciptService, IPaymentService paymentService)
        {
            this.reciptService = reciptService;
            this.paymentService = paymentService;
        }

        public Operation operation => Operation.PhysicalProduct;
        public void DoThing(string eventDefined)
        {
            Console.WriteLine("Physical Product Rules");

            this.reciptService.GenerateRecipt(eventDefined);
            this.paymentService.GenerateCommissionPayment(eventDefined);
        }
    }
}
