﻿using BusinessRuleEngine.Resolver;
using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.ProductRule
{
    public class UpgradeRule : IEventServiceOperation
    {
        private readonly IMembership membership;
        private readonly IEmailService emailService;
        public UpgradeRule(IMembership membership, IEmailService emailService)
        {
            this.membership = membership;
            this.emailService = emailService;
        }
        public Operation operation => Operation.UpGrade;

        public void DoThing(string eventDefined)
        {
            Console.WriteLine("Iam Upgrading");
            this.membership.UpgradeMembership(eventDefined);
            this.emailService.SendMail(eventDefined);
        }
    }
}
