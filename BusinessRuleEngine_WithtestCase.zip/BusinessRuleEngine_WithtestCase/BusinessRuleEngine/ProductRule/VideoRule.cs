﻿using BusinessRuleEngine.Resolver;
using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.ProductRule
{
    public class VideoRule : IEventServiceOperation
    {
        private readonly IAddExtraService addExtraService;
        public VideoRule(IAddExtraService addExtraService)
        {
            this.addExtraService = addExtraService;
        }
        public Operation operation => Operation.Video;

        public void DoThing(string eventDefined)
        {
            Console.WriteLine("Video Service");

            if(eventDefined.Equals("Learning To Ski", StringComparison.OrdinalIgnoreCase))
            {
                this.addExtraService.AddingExtra();
            }
        }
    }
}
