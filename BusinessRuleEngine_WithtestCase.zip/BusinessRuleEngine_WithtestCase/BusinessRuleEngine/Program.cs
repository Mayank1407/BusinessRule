﻿using BusinessRuleEngine.ProductRule;
using BusinessRuleEngine.Resolver;
using BusinessRuleEngine.RuleConfigure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;

namespace BusinessRuleEngine
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Hello");

            var _serviceProvider = RegisterServices();

            Console.WriteLine("Please select recipt");
            var strategyFor = Console.ReadLine();
            Console.WriteLine();
            string eventModel = string.Empty;
            if (strategyFor.Equals("PhysicalProduct", StringComparison.OrdinalIgnoreCase) || strategyFor.Equals("OrderBook", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Please Enter Agent Name");
                eventModel = Console.ReadLine();
                Console.WriteLine();
            }
            if (strategyFor.Equals("Membership", StringComparison.OrdinalIgnoreCase) || strategyFor.Equals("Upgrade", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Please Enter Owner EmailID");
                eventModel = Console.ReadLine();
                Console.WriteLine();
            }
            if (strategyFor.Equals("Video", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Please Enter Book Name");
                eventModel = Console.ReadLine();
                Console.WriteLine();
            }
            IServiceScope scope = _serviceProvider.CreateScope();
            scope.ServiceProvider.GetRequiredService<ConsoleApplication>().Run(strategyFor, eventModel);

            Console.ReadKey();
        }

        private static ServiceProvider RegisterServices()
        {
            //setup our DI
            var serviceProvider = new ServiceCollection()
                .AddScoped<ConsoleApplication>()
                .AddSingleton<IBusinesssRuleManager, BusinesssRuleManager>()
                .AddSingleton<IEventService, EventService>()
                .AddSingleton<IMembership, Membership>()
                .AddSingleton<IEmailService, EmailService>()
                .AddSingleton<IReciptService, ReciptService>()
                .AddSingleton<IPaymentService, PaymentService>()
                .AddSingleton<IAddExtraService, AddExtraService>()
                .AddSingleton<IEventServiceOperation, BookRule>()
                .AddSingleton<IEventServiceOperation, UpgradeRule>()
                .AddSingleton<IEventServiceOperation, MembershipRule>()
                .AddSingleton<IEventServiceOperation, VideoRule>()
                .AddSingleton<IEventServiceOperation, PhysicalProduct>();


            var provider = serviceProvider.BuildServiceProvider(true);

            return provider;
        }
    }
}
