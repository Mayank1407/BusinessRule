﻿using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.Resolver
{

    public enum Operation
    {
        OrderBook,
        PhysicalProduct,
        Membership,
        UpGrade,
        Video
    }


    public interface IBusinesssRuleManager
    {
        void ApplyStrategy(string type,string eventModel);
    }

}
