﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public class AddExtraService : IAddExtraService
    {
        public void AddingExtra()
        {
            Console.WriteLine("I am Adding Extra");
        }
    }
}
