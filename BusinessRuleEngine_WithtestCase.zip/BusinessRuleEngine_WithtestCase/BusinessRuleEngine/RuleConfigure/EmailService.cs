﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public class EmailService : IEmailService
    {
        public void SendMail(string EventName)
        {
            Console.WriteLine($"{EventName} Sending Mail");
        }
    }
}
