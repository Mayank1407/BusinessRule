﻿using BusinessRuleEngine.Resolver;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public class EventService : IEventService
    {
        public void DoThing(string eventDefined)
        {
            Console.WriteLine("Test eventDefined");
        }
    }
}
