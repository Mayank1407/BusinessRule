﻿using BusinessRuleEngine.Resolver;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public interface IEventService
    {
        void DoThing(string eventDefined);
    }

}
