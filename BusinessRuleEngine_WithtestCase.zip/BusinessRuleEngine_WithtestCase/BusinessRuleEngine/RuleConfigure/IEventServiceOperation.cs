﻿using BusinessRuleEngine.Resolver;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public interface IEventServiceOperation
    {
        Operation operation { get; }
        void DoThing(string eventDefined);
    }
}
