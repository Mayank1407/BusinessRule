﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public interface IMembership
    {
        void GenerateMembership(string EventName);

        void UpgradeMembership(string EventName);
    }
}
