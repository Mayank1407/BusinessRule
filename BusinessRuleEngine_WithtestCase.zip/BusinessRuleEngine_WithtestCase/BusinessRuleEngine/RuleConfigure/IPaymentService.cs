﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public interface IPaymentService
    {
        void GenerateCommissionPayment(string agentName);
    }
}
