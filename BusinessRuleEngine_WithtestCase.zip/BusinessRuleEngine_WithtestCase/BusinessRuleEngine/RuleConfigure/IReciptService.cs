﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public interface IReciptService
    {
        void GenerateRecipt(string agentName);

        void DuplicateRecipt(string agentName);
    }
}
