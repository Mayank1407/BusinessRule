﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public class Membership : IMembership
    {
        public void GenerateMembership(string EventName)
        {
            Console.WriteLine($"Create Membership for {EventName}");
        }

        public void UpgradeMembership(string EventName)
        {
            Console.WriteLine($"UpGrade Membership for {EventName}");
        }
    }
}
