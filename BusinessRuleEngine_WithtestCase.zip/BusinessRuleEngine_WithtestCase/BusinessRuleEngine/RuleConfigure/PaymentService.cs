﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public class PaymentService : IPaymentService
    {
        public void GenerateCommissionPayment(string agentName)
        {
            Console.WriteLine($"GenerateCommision Payment for {agentName}");
        }
    }
}
