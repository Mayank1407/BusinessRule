﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.RuleConfigure
{
    public class ReciptService : IReciptService
    {
        public void DuplicateRecipt(string agentName)
        {
            Console.WriteLine($"Duplicate Slip for packing Royality Department {agentName}");
        }

        public void GenerateRecipt(string agentName)
        {
            Console.WriteLine($"Generate Slip for packing {agentName}");
        }
    }
}
