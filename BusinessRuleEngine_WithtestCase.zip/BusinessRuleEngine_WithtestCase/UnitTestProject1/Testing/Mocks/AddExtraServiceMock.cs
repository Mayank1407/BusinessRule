﻿using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTestProject1.Testing.Mocks
{
    public class AddExtraServiceMock : IAddExtraService
    {
        public int AddingExtraCOunt { get; set; }
        public Action AddingExtraDelegate { get; set; }
        public void AddingExtra()
        {
            AddingExtraCOunt++;
            this.AddingExtraDelegate();
        }
    }
}
