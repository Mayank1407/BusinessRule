﻿using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTestProject1.Testing.Mocks
{
    public class EmailServiceMock : IEmailService
    {
        public int SendMailCount { get; set; }
        public Action<string> SendMailDelegate { get; set; }
        public void SendMail(string EventName)
        {
            SendMailCount++;
            this.SendMailDelegate(EventName);
        }
    }
}
