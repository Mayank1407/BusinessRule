﻿using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.Testing
{
    public class EventServiceMock : IEventService
    {
        public int DoThingCount { get; set; }
        public Action<string> DoThingDelegate { get; set; }

        public void DoThing(string eventDefined)
        {
            DoThingCount++;
            this.DoThingDelegate(eventDefined);
        }
    }
}
