﻿using BusinessRuleEngine.Resolver;
using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.Testing.Mocks
{
    public class EventServiceOperationMock : IEventServiceOperation
    {
        public int DoThingCount { get; set; }
        public Operation operation { get; set; }

        public void AddOperationDelegate(Operation operationype)
        {
            this.operation = operationype;
        }

        public Action<string> DoThingDelegate { get; set; }

        public void DoThing(string eventDefined)
        {
            DoThingCount++;
            this.DoThingDelegate(eventDefined);
        }
    }
}
