﻿using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTestProject1.Testing.Mocks
{
    public class MembershipMock : IMembership
    {
        public int UpgradeMembershipCount { get; set; }
        public int GenerateMembershipCount { get; set; }
        public Action<string> UpgradeMembershipDelegate { get; set; }
        public Action<string> GenerateMembershipDelegate { get; set; }

        public void GenerateMembership(string EventName)
        {
            GenerateMembershipCount++;
            this.GenerateMembershipDelegate(EventName);
        }

        public void UpgradeMembership(string EventName)
        {
            UpgradeMembershipCount++;
            this.UpgradeMembershipDelegate(EventName);
        }
    }
}
