﻿using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTestProject1.Testing.Mocks
{
    public class PaymentServiceMock : IPaymentService
    {
        public int GenerateCommissionCount { get; set; }
        public Action<string> GenerateCommissionPaymentDelegate { get; set; }
        public void GenerateCommissionPayment(string agentName)
        {
            GenerateCommissionCount++;
            this.GenerateCommissionPaymentDelegate(agentName);
        }
    }
}
