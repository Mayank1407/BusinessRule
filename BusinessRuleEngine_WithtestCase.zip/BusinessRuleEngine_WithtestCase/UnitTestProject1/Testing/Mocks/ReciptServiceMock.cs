﻿using BusinessRuleEngine.RuleConfigure;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace UnitTestProject1.Testing.Mocks
{
    public class ReciptServiceMock : IReciptService
    {
        public int DuplicateReciptCount { get; set; }
        public int GenerateReciptCount { get; set; }
        public Action<string> DuplicateReciptDelegate { get; set; }
        public Action<string> GenerateReciptDelegate { get; set; }

        public void DuplicateRecipt(string agentName)
        {
            DuplicateReciptCount++;
            this.DuplicateReciptDelegate(agentName);
        }

        public void GenerateRecipt(string agentName)
        {
            GenerateReciptCount++;
            this.GenerateReciptDelegate(agentName);
        }
    }
}
