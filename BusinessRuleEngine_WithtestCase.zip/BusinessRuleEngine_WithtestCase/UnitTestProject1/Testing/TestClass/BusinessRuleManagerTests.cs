﻿using BusinessRuleEngine.Resolver;
using BusinessRuleEngine.Testing.Mocks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine.Testing.TestClass
{
    [TestClass]
    public class BusinessRuleManagerTests
    {
        [TestMethod]
        public void BusinessRuleManager_WithValidStrategy_ForBook_ApplyStrategy_Success()
        {
            // SetUp
            var eventServiceMock = new EventServiceOperationMock();

            eventServiceMock.AddOperationDelegate(Operation.OrderBook);
            eventServiceMock.DoThingDelegate = (eventName) =>
            {
                Assert.AreEqual("eventModel", eventName);
            };
            var list = new List<EventServiceOperationMock>();
            list.Add(eventServiceMock);

            // Action
            var businessRule = new BusinesssRuleManager(list);
            businessRule.ApplyStrategy("OrderBook", "eventModel");

            // Assertion
            Assert.AreEqual(1, eventServiceMock.DoThingCount);
        }
        [TestMethod]
        public void BusinessRuleManager_WithValidStrategy_ForPhysicalProduct_ApplyStrategy_Success()
        {
            // SetUp
            var eventServiceMock = new EventServiceOperationMock();

            eventServiceMock.AddOperationDelegate(Operation.PhysicalProduct);
            eventServiceMock.DoThingDelegate = (eventName) =>
            {
                Assert.AreEqual("eventModel", eventName);
            };
            var list = new List<EventServiceOperationMock>();
            list.Add(eventServiceMock);

            // Action
            var businessRule = new BusinesssRuleManager(list);
            businessRule.ApplyStrategy("PhysicalProduct", "eventModel");

            // Assertion
            Assert.AreEqual(1, eventServiceMock.DoThingCount);
        }

        [TestMethod]
        public void BusinessRuleManager_WithInValidStrategy_ShouldNotCallDoThing()
        {
            // SetUp
            var eventServiceMock = new EventServiceOperationMock();
            eventServiceMock.AddOperationDelegate(Operation.PhysicalProduct);
            var list = new List<EventServiceOperationMock>();
            list.Add(eventServiceMock);

            // Action
            var businessRule = new BusinesssRuleManager(list);
            businessRule.ApplyStrategy("OrderBookNotExist", "eventModel");

            // Assertion
            Assert.AreEqual(0, eventServiceMock.DoThingCount);
        }
    }
}
