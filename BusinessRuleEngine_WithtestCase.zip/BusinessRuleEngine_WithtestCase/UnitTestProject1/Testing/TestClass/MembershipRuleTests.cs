﻿using BusinessRuleEngine.ProductRule;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using UnitTestProject1.Testing.Mocks;

namespace UnitTestProject1.Testing.TestClass
{
    [TestClass]
    public class MembershipRuleTests
    {
        [TestMethod]
        public void DoThing_WithReciptService_success()
        {
            // SetUp
            var parameterPassed = "paramEmailPassed";
            var emailService = new EmailServiceMock();
            emailService.SendMailDelegate = (email) =>
            {
                // Same what you passed as parameter 
                Assert.AreEqual(parameterPassed, email);
            };
            var memberService = new MembershipMock();
            memberService.GenerateMembershipDelegate = (email) =>
            {
                // Same what you passed as parameter 
                Assert.AreEqual(parameterPassed, email);
            };
            // Action
            var action = new MembershipRule(memberService, emailService);
            action.DoThing(parameterPassed);

            // Assertion
            Assert.AreEqual(1, emailService.SendMailCount);
            Assert.AreEqual(1, memberService.GenerateMembershipCount);
        }
    }
}
