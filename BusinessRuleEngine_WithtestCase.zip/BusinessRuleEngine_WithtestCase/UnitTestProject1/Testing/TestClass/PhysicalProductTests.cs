﻿using BusinessRuleEngine.ProductRule;
using BusinessRuleEngine.Resolver;
using BusinessRuleEngine.Testing.Mocks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using UnitTestProject1.Testing.Mocks;

namespace UnitTestProject1.Testing.TestClass
{
    [TestClass]
    public class PhysicalProductTests
    {
        [TestMethod]
        public void DoThing_WithReciptService_success()
        {
            // SetUp
            var parameterPassed = "paramPassed";
            var recieptService = new ReciptServiceMock();
            recieptService.GenerateReciptDelegate = (agentName) =>
            {
                // Same what you passed as parameter 
                Assert.AreEqual(parameterPassed, agentName);
            };
            var paymentService = new PaymentServiceMock();
            paymentService.GenerateCommissionPaymentDelegate = (agentName) =>
            {
                // Same what you passed as parameter 
                Assert.AreEqual(parameterPassed, agentName);
            };
            // Action
            var action = new PhysicalProduct(recieptService, paymentService);
            action.DoThing(parameterPassed);

            // Assertion
            Assert.AreEqual(1, recieptService.GenerateReciptCount);
            Assert.AreEqual(0, recieptService.DuplicateReciptCount);
        }
        [TestMethod]
        [ExpectedException(typeof(System.NullReferenceException))]
        public void DoThing_WithReciptService_ServiceNotImplemented_NullReferenceException()
        {
            // SetUp
            var parameterPassed = "paraMeter";
            var reciptService = new ReciptServiceMock();
            reciptService.DuplicateReciptDelegate = (agentName) =>
            {
                // Same what you passed as parameter 
                Assert.AreEqual(parameterPassed, agentName);
            };

            // Action
            var action = new PhysicalProduct(reciptService, new PaymentServiceMock());
            action.DoThing(parameterPassed);
        }
    }
}
