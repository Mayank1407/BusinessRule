﻿using BusinessRuleEngine.ProductRule;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using UnitTestProject1.Testing.Mocks;

namespace UnitTestProject1.Testing.TestClass
{
    [TestClass]
    public class VideoRuleTests
    {
        [TestMethod]
        public void VideoRule_WithLearningToSKiBook_ShouldAddExtra()
        {
            // SetUp
            var parameterPassed = "Learning To Ski";
            var addExtra = new AddExtraServiceMock();
            addExtra.AddingExtraDelegate = () =>
            {
            };
            // Action
            var action = new VideoRule(addExtra);
            action.DoThing(parameterPassed);

            // Assertion
            Assert.AreEqual(1, addExtra.AddingExtraCOunt);
        }

        [TestMethod]
        public void VideoRule_WithOutLearningToSKiBook_ShouldNotAddExtraCount()
        {
            // SetUp
            var parameterPassed = "FakeBook";
            var addExtra = new AddExtraServiceMock();
            addExtra.AddingExtraDelegate = () =>
            {
            };
            // Action
            var action = new VideoRule(addExtra);
            action.DoThing(parameterPassed);

            // Assertion
            Assert.AreEqual(0, addExtra.AddingExtraCOunt);
        }
    }
}
